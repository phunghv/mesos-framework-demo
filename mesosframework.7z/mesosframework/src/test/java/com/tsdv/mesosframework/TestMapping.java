package com.tsdv.mesosframework;

import java.util.HashMap;
import java.util.Map;

public class TestMapping {

	private Map<String, String> a = null;

	public TestMapping(Map<String, String> a) {
		this.a = a;
	}

	public void run() {
		System.out.println("Size TestMapping = " + this.a.size());
		a.put("2", "2");
		System.out.println("Size TestMapping = " + this.a.size());
	}

	public static void main(String[] args) {
		Map<String, String> x = new HashMap<String, String>();
		x.put("1", "2");
		TestMapping t1 = new TestMapping(x);
		t1.run();
		TestMapping2 t2 = new TestMapping2(x);
		t2.run();
	}

}

class TestMapping2 {
	private Map<String, String> a = null;

	public TestMapping2(Map<String, String> a) {
		this.a = a;
	}

	public void run() {
		System.out.println("Size TestMapping 2 = " + this.a.size());
		a.remove("1");
		System.out.println("Size TestMapping 2 = " + this.a.size());
	}
}