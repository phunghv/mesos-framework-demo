package com.tsdv.mesosframework.api;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import com.sun.jersey.spi.container.servlet.ServletContainer;

public class APIServer {
	private Server server;
	private ServletHolder sh;
	private ServletContextHandler context;
	public APIServer(int port) {
		sh = new ServletHolder(ServletContainer.class);
		
		sh.setInitParameter(
				"com.sun.jersey.config.property.resourceConfigClass",
				"com.sun.jersey.api.core.PackagesResourceConfig");
		sh.setInitParameter("com.sun.jersey.config.property.packages",
				"com.tsdv.mesosframework.api");
		sh.setInitParameter("com.sun.jersey.api.json.POJOMappingFeature",
				"true");
		server = new Server(port);

		context = new ServletContextHandler(server, "/",
				ServletContextHandler.SESSIONS);
		context.addServlet(sh, "/api/*");
	}

	public void start() throws Exception {
		server.start();
		server.join();
	}

	public void shutdown() throws Exception {
		server.stop();
	}
	public static void main(String[] args) throws Exception {
		APIServer a = new APIServer(8008);
		a.start();
	}
}