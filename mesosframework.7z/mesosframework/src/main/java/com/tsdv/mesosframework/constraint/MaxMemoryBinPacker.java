package com.tsdv.mesosframework.constraint;

import com.netflix.fenzo.TaskRequest;
import com.netflix.fenzo.TaskTrackerState;
import com.netflix.fenzo.VMTaskFitnessCalculator;
import com.netflix.fenzo.VirtualMachineCurrentState;

public class MaxMemoryBinPacker implements VMTaskFitnessCalculator{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double calculateFitness(TaskRequest taskRequest,
			VirtualMachineCurrentState targetVM,
			TaskTrackerState taskTrackerState) {
		// TODO Auto-generated method stub
		return 0;
	}

}



