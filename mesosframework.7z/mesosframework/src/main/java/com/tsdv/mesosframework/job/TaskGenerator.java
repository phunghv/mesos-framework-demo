package com.tsdv.mesosframework.job;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
/**
 * Class implement how to generate a or more {Task} from a {Job}
 * 
 * @author phunghv
 * 
 */
public class TaskGenerator {
	public static Task generate(Job job) {
		String id = job.getName() + "_" + UUID.randomUUID();
		return new Task(id, job);
	}
	public static List<Task> genrate(Job job, int instanceNo) {
		List<Task> result = new ArrayList<>();
		String id = job.getName() + "_" + UUID.randomUUID();
		for (int i = 1; i <= instanceNo; i++) {
			result.add(new Task(id + String.format("%4d", i), job));
		}
		return result;
	}
}
