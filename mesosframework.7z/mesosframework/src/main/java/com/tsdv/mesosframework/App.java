package com.tsdv.mesosframework;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.tsdv.mesosframework.api.APIServer;
import com.tsdv.mesosframework.job.Job;
import com.tsdv.mesosframework.job.JobParser;
import com.tsdv.mesosframework.job.Task;
import com.tsdv.mesosframework.job.TaskGenerator;
import com.tsdv.mesosframework.scheduler.CustomFramework;
import com.tsdv.mesosframework.zookeepr.ZookeeperUtils;

/**
 * Hello world!
 *
 */
public class App {
	final Logger logger = LogManager.getLogger(App.class);
	static final String MASTER_STRING = "localhost:2181";
	static final String FRAMEWORK_PATH = "/customframework";
	static final String FRAMEWORK_NAME = "Custom Fenzo Framework";
	private CustomFramework framework;
	private BlockingQueue<Task> queue = new LinkedBlockingQueue<Task>();

	public void loadJobFile(String file) throws InterruptedException {
		List<Job> list = JobParser.parse(file);
		logger.info("Load {} jobs from {}", list.size(), file);
		for (Job j : list) {
			Task t = TaskGenerator.generate(j);
			queue.put(t);
		}
	}

	public void initialize(String name, String path, String file)
			throws InterruptedException {
		logger.info("init with {} and {}", name, path);
		ZookeeperUtils zk = new ZookeeperUtils(MASTER_STRING);
		zk.electLeader(path);
		loadJobFile("jobs.json");
		final APIServer server = new APIServer(8008);
		framework = new CustomFramework(FRAMEWORK_NAME, 8008, queue,
				MASTER_STRING);
		new Thread(new Runnable() {

			@Override
			public void run() {
				framework.start();
			}
		}).start();

		try {
			server.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws InterruptedException {
		String file = args[0] == null ? "jobs.json" : args[0];
		App app = new App();
		app.initialize(FRAMEWORK_NAME, FRAMEWORK_PATH, file);

	}
}
