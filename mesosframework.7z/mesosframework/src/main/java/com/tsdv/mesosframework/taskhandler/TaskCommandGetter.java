package com.tsdv.mesosframework.taskhandler;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.netflix.fenzo.functions.Func1;
import com.tsdv.mesosframework.job.Job;

public class TaskCommandGetter implements Func1<String, String> {

	private AtomicReference<Map<String, Job>> listJobs = null;

	public TaskCommandGetter(AtomicReference<Map<String, Job>> listJobs) {
		this.listJobs = listJobs;
	}

	@Override
	public String call(String taskId) {
		Job job = listJobs.get().get(taskId);
		if (listJobs == null || job == null) {
			return null;
		} else {
			return job.getCommand();
		}
	}

}
