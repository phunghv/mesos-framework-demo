package com.tsdv.mesosframework.constraint;

import java.util.List;

import com.netflix.fenzo.ConstraintEvaluator;
import com.netflix.fenzo.TaskRequest;
import com.netflix.fenzo.TaskTrackerState;
import com.netflix.fenzo.VirtualMachineCurrentState;

public class NodeAttributeConstraint implements ConstraintEvaluator {
	String name;
	List<String> attributes;

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result evaluate(TaskRequest taskRequest,
			VirtualMachineCurrentState targetVM,
			TaskTrackerState taskTrackerState) {
		// TODO Auto-generated method stub
		return null;
	}

}
