package com.tsdv.mesosframework.constraint;

import com.netflix.fenzo.ConstraintEvaluator;
import com.netflix.fenzo.TaskRequest;
import com.netflix.fenzo.TaskTrackerState;
import com.netflix.fenzo.VirtualMachineCurrentState;

public class MaxMemoryConstraint implements ConstraintEvaluator {
	String name;

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result evaluate(TaskRequest taskRequest,
			VirtualMachineCurrentState targetVM,
			TaskTrackerState taskTrackerState) {
			
		
		// TODO Auto-generated method stub
		return null;
	}

}
