package com.tsdv.mesosframework.job;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.tsdv.mesosframework.exception.ErrorSyntaxJobException;

public class JobParser {
	public static Job parse(JSONObject json) throws ErrorSyntaxJobException {
		String name = json.has("name") ? json.getString("name") : "Job name";
		String command = json.has("command") ? json.getString("command") : null;
		String groupName = json.has("group") ? json.getString("group") : null;
		double cpus = json.has("cpus") ? json.getDouble("cpus") : 0.01;
		double memory = json.has("mem") ? json.getDouble("mem") : 64;
		double disk = json.has("disk") ? json.getDouble("disk") : 10;
		int port = json.has("port") ? json.getInt("port") : 1;
		double networkMbps = json.has("network")
				? json.getDouble("network")
				: 0;

		return new Job(name, command, cpus, memory, groupName, disk, port,
				networkMbps, null);
	}
	public static List<Job> parse(String jobFileName) {
		List<Job> result = new ArrayList<>();
		try {
			byte[] data = Files.readAllBytes(Paths.get(jobFileName));
			JSONObject config = new JSONObject(new String(data, "UTF-8"));
			JSONArray jobsArray = config.getJSONArray("jobs");
			for (int i = 0; i < jobsArray.length(); i++) {
				Job current = parse(jobsArray.getJSONObject(i));
				result.add(current);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
