package com.tsdv.mesosframework.taskhandler;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.netflix.fenzo.functions.Action1;
import com.tsdv.mesosframework.job.Job;
import com.tsdv.mesosframework.job.Task;
import com.tsdv.mesosframework.job.TaskState;

public class TaskCompleteAction implements Action1<String> {

	private AtomicReference<Map<String, Task>> tasks = null;

	public TaskCompleteAction(AtomicReference<Map<String, Task>> tasks) {
		this.tasks = tasks;
	}

	@Override
	public void call(String taskId) {
		Task task = tasks.get().get(taskId);
		if (tasks == null || task == null) {
			return;
		} else {
			task.setStatus(TaskState.SUCCESSFUL);
			task.setSubmit(true);
		}
	}

}
