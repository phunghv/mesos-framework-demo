package com.tsdv.mesosframework.taskhandler;

public class TaskFailureAction {

}
