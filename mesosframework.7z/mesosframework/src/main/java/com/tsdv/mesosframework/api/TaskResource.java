package com.tsdv.mesosframework.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

@Path("/task")
public class TaskResource {

	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public Response listJob(@Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		List<JSONObject> list = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			try {
				JSONObject obj = new JSONObject();

				obj.put("Taskname_" + i, "foo" + i);
				obj.put("num", new Integer(100));
				obj.put("balance", new Double(1000.21));
				obj.put("is_vip", new Boolean(true));
				list.add(obj);
				System.out.println("Add a");
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		JSONArray arr = new JSONArray(list);
		return Response.status(200).entity(arr).build();
	}

	@POST
	@Path("/task")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response postDataStream(@Context HttpServletRequest request,
			@Context HttpServletResponse response) {

		String body = null;
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;

		try {
			InputStream inputStream = request.getInputStream();
			if (inputStream != null) {
				bufferedReader = new BufferedReader(
						new InputStreamReader(inputStream));
				char[] charBuffer = new char[128];
				int bytesRead = -1;
				while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
					stringBuilder.append(charBuffer, 0, bytesRead);
				}
			} else {
				stringBuilder.append("");
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}

		}

		body = stringBuilder.toString();
		return Response.status(200).entity(body).build();
	}

}
