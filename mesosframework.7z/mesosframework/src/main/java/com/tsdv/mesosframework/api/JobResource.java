package com.tsdv.mesosframework.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.tsdv.mesosframework.job.Job;

@Path("/job")
public class JobResource {

	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public Response listJob(@Context HttpServletRequest request,
			@Context HttpServletResponse response) {
		Job job = new Job("jobname", "ls -la", 1, 128, "sadas", 12, 1, 1, null);
		return Response.status(200).entity(job).build();
	}

	@POST
	@Path("/job")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response postDataStream(@Context HttpServletRequest request,
			@Context HttpServletResponse response) {

		String body = null;
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;

		try {
			InputStream inputStream = request.getInputStream();
			if (inputStream != null) {
				bufferedReader = new BufferedReader(
						new InputStreamReader(inputStream));
				char[] charBuffer = new char[128];
				int bytesRead = -1;
				while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
					stringBuilder.append(charBuffer, 0, bytesRead);
				}
			} else {
				stringBuilder.append("");
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}

		}

		body = stringBuilder.toString();
		return Response.status(200).entity(body).build();
	}

}
