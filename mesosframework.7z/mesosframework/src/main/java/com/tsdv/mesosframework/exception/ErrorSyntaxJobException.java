package com.tsdv.mesosframework.exception;

public class ErrorSyntaxJobException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9070218803936146860L;
	public ErrorSyntaxJobException() {
		super();
	}
	public ErrorSyntaxJobException(String message) {
		super(message);
	}
}
