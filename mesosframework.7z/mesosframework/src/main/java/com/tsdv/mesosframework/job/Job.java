package com.tsdv.mesosframework.job;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

import com.google.common.collect.ImmutableMap;
import com.netflix.fenzo.ConstraintEvaluator;
import com.netflix.fenzo.VMTaskFitnessCalculator;

@XmlRootElement
public class Job implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2809459109881735024L;

	private String name;
	private String command;
	private String groupName;
	private double cpus;
	private double memory;
	private double disk;
	private int port;
	private double networkMbps;
	private Map<String, String> environment = new HashMap<>();
	private List<ConstraintEvaluator> newlyHardConstraints;
	private List<VMTaskFitnessCalculator> newlySoftConstaints;
	private List<ConstraintEvaluator> failoverHardConstraints;
	private List<VMTaskFitnessCalculator> failoverSoftConstaints;

	public Job(String name, String command, double cpus, double memory,
			String groupName, double disk, int port, double network,
			Map<String, String> environment) {
		this.name = name;
		this.groupName = groupName;
		this.command = command;
		this.cpus = cpus;
		this.memory = memory;
		this.disk = disk;
		this.port = port;
		this.networkMbps = network;
		this.environment = environment;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public double getCpus() {
		return cpus;
	}

	public void setCpus(double cpus) {
		this.cpus = cpus;
	}

	public double getMemory() {
		return memory;
	}

	public void setMemory(double memory) {
		this.memory = memory;
	}

	public double getDisk() {
		return disk;
	}

	public void setDisk(double disk) {
		this.disk = disk;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public double getNetworkMbps() {
		return networkMbps;
	}

	public void setNetworkMbps(double networkMbps) {
		this.networkMbps = networkMbps;
	}

	public Map<String, String> getEnvironment() {
		return environment;
	}

	public void setEnvironment(Map<String, String> environment) {
		this.environment = environment;
	}

	public List<ConstraintEvaluator> getNewlyHardConstraints() {
		return newlyHardConstraints;
	}

	public void setNewlyHardConstraints(
			List<ConstraintEvaluator> newlyHardConstraints) {
		this.newlyHardConstraints = newlyHardConstraints;
	}

	public List<VMTaskFitnessCalculator> getNewlySoftConstaints() {
		return newlySoftConstaints;
	}

	public void setNewlySoftConstaints(
			List<VMTaskFitnessCalculator> newlySoftConstaints) {
		this.newlySoftConstaints = newlySoftConstaints;
	}

	public List<ConstraintEvaluator> getFailoverHardConstraints() {
		return failoverHardConstraints;
	}

	public void setFailoverHardConstraints(
			List<ConstraintEvaluator> failoverHardConstraints) {
		this.failoverHardConstraints = failoverHardConstraints;
	}

	public List<VMTaskFitnessCalculator> getFailoverSoftConstaints() {
		return failoverSoftConstaints;
	}

	public void setFailoverSoftConstaints(
			List<VMTaskFitnessCalculator> failoverSoftConstaints) {
		this.failoverSoftConstaints = failoverSoftConstaints;
	}

}
