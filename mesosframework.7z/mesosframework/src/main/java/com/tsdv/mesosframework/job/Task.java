package com.tsdv.mesosframework.job;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.netflix.fenzo.ConstraintEvaluator;
import com.netflix.fenzo.TaskRequest;
import com.netflix.fenzo.VMTaskFitnessCalculator;

public class Task implements TaskRequest {
	private static final int RETRIES_NUM = 5;
	private final String id;
	private final Job job;
	private int retries;
	private boolean isSubmit;
	private TaskState status;
	private boolean isFailed;
	private String hostname;

	final AtomicReference<TaskRequest.AssignedResources> assgndResRef = new AtomicReference<>();

	public Task(String id, Job job) {
		this.id = id;
		this.job = job;
		this.status = TaskState.PENDING;
		this.retries = RETRIES_NUM;
		this.isSubmit = false;
	}

	public boolean isSummit() {
		return isSubmit;
	}

	public void setSubmit(boolean isSubmit) {
		this.isSubmit = isSubmit;
	}

	public int getRetries() {
		return retries;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public void setRetries(int retries) {
		this.retries = retries;
	}

	public TaskState getStatus() {
		return status;
	}

	public void setStatus(TaskState status) {
		this.status = status;
	}

	public String getCommand() {
		return job.getCommand();
	}
	public String getName() {
		return job.getName();
	}

	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public String taskGroupName() {
		return job.getGroupName();
	}

	@Override
	public double getCPUs() {
		return job.getCpus();
	}

	@Override
	public double getMemory() {
		return job.getMemory();
	}

	@Override
	public double getNetworkMbps() {
		return job.getNetworkMbps();
	}

	@Override
	public double getDisk() {
		return job.getDisk();
	}

	@Override
	public int getPorts() {
		return job.getPort();
	}

	@Override
	public Map<String, Double> getScalarRequests() {
		return null;
	}

	@Override
	public Map<String, NamedResourceSetRequest> getCustomNamedResources() {
		return Collections.emptyMap();
	}

	@Override
	public List<? extends ConstraintEvaluator> getHardConstraints() {
		if (this.isFailed) {
			return job.getFailoverHardConstraints();
		}
		return job.getNewlyHardConstraints();
	}

	@Override
	public List<? extends VMTaskFitnessCalculator> getSoftConstraints() {
		if (this.isFailed) {
			return job.getFailoverSoftConstaints();
		}
		return job.getNewlySoftConstaints();
	}

	@Override
	public void setAssignedResources(AssignedResources assignedResources) {
		assgndResRef.set(assignedResources);

	}

	@Override
	public AssignedResources getAssignedResources() {
		return assgndResRef.get();
	}

}
