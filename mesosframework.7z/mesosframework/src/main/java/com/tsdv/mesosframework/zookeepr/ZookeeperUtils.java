package com.tsdv.mesosframework.zookeepr;

import java.io.IOException;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.leader.LeaderLatch;
import org.apache.curator.retry.RetryOneTime;

public class ZookeeperUtils {
	private final CuratorFramework curator;
	public ZookeeperUtils(String master) {
		curator = CuratorFrameworkFactory.newClient(master,
				new RetryOneTime(1000));
	}
	/**
	 * Function elect a leader for framework
	 */
	public void electLeader(String path) {
		curator.start();
		LeaderLatch leaderLatch = new LeaderLatch(curator, path);
		try {
			leaderLatch.start();
			leaderLatch.await();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				leaderLatch.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * Function load data from a {String} path
	 * 
	 * @param path
	 * @return
	 * @throws Exception
	 */
	public byte[] loadData(String path) throws Exception {
		return curator.getData().forPath(path);
	}
	/**
	 * 
	 * @param path
	 * @param data
	 * @return
	 */
	public boolean saveData(String path, byte[] data) {
		try {
			curator.create().creatingParentsIfNeeded().forPath(path, data);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
