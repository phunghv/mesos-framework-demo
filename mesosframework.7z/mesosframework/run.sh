java -Djava.library.path=/usr/local/lib -jar target/mesosframework-0.0.1-SNAPSHOT-jar-with-dependencies.jar localhost:2181
