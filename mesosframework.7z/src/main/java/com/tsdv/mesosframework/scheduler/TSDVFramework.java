package com.tsdv.mesosframework.scheduler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.mesos.MesosSchedulerDriver;
import org.apache.mesos.Protos;
import org.apache.mesos.Protos.ExecutorID;
import org.apache.mesos.Protos.FrameworkID;
import org.apache.mesos.Protos.MasterInfo;
import org.apache.mesos.Protos.Offer;
import org.apache.mesos.Protos.OfferID;
import org.apache.mesos.Protos.SlaveID;
import org.apache.mesos.Protos.TaskStatus;
import org.apache.mesos.Scheduler;
import org.apache.mesos.SchedulerDriver;

import com.netflix.fenzo.SchedulingResult;
import com.netflix.fenzo.TaskAssignmentResult;
import com.netflix.fenzo.TaskRequest;
import com.netflix.fenzo.TaskScheduler;
import com.netflix.fenzo.VMAssignmentResult;
import com.netflix.fenzo.VirtualMachineLease;
import com.netflix.fenzo.functions.Action1;
import com.netflix.fenzo.functions.Func1;
import com.netflix.fenzo.plugins.VMLeaseObject;
import com.tsdv.mesosframework.job.Job;

public class TSDVFramework {
	final static Logger logger = LogManager.getLogger(TSDVFramework.class);

	public class CustomScheduler implements Scheduler {

		@Override
		public void registered(SchedulerDriver driver, FrameworkID frameworkId,
				MasterInfo masterInfo) {
			logger.info("Registered framework with id {}", frameworkId);
			scheduler.expireAllLeases();
		}

		@Override
		public void reregistered(SchedulerDriver driver,
				MasterInfo masterInfo) {
			logger.info("Re-registered framework");
			scheduler.expireAllLeases();

		}

		@Override
		public void resourceOffers(SchedulerDriver driver, List<Offer> offers) {
			for (Protos.Offer offer : offers) {
				if (pendingTasksMap.isEmpty() && ref.get() != null) {
					logger.info("Decline offer id {}", offer.getId());
					ref.get().declineOffer(offer.getId());
				} else {
					logger.info("Adding offer {} from host {}", offer.getId(),
							offer.getHostname());
					leasesQueue.offer(new VMLeaseObject(offer));
				}
			}
		}

		@Override
		public void offerRescinded(SchedulerDriver driver, OfferID offerId) {
			logger.info("Offer rescinded with offer id = {}",
					offerId.getValue());
			scheduler.expireLease(offerId.getValue());

		}

		@Override
		public void statusUpdate(SchedulerDriver driver, TaskStatus status) {
			switch (status.getState()) {
			case TASK_ERROR:
				break;
			case TASK_FAILED:
				break;
			case TASK_FINISHED:
				break;
			case TASK_KILLED:
				break;
			case TASK_KILLING:
				break;
			case TASK_LOST:
				break;
			case TASK_RUNNING:
				break;
			case TASK_STAGING:
				break;
			case TASK_STARTING:
				break;
			default:

			}
		}

		@Override
		public void frameworkMessage(SchedulerDriver driver,
				ExecutorID executorId, SlaveID slaveId, byte[] data) {
			logger.info("Framework message {}", new String(data));
		}

		@Override
		public void disconnected(SchedulerDriver driver) {
			logger.info("Framework disconnected");

		}

		@Override
		public void slaveLost(SchedulerDriver driver, SlaveID slaveId) {
			scheduler.expireAllLeasesByVMId(slaveId.getValue());

		}

		@Override
		public void executorLost(SchedulerDriver driver, ExecutorID executorId,
				SlaveID slaveId, int status) {
			logger.info("Executor {} lost, status= {}", executorId.getValue(),
					status);

		}

		@Override
		public void error(SchedulerDriver driver, String message) {
			logger.info("Error with message {}", message);
		}

	}

	private final BlockingQueue<TaskRequest> taskQueue;
	private final Map<String, Job> mapTasks;
	private final BlockingQueue<VirtualMachineLease> leasesQueue;
	private final Map<String, String> launchedTasks;
	private final TaskScheduler scheduler;
	private final MesosSchedulerDriver mesosSchedulerDriver;
	private final AtomicReference<MesosSchedulerDriver> ref = new AtomicReference<>();
	private final Map<String, TaskRequest> pendingTasksMap = new HashMap<>();
	private final AtomicBoolean isShutdown = new AtomicBoolean(false);
	private final Func1<String, String> taskCmdGetter;

	public TSDVFramework(BlockingQueue<TaskRequest> taskQueue,
			String mesosMaster) {
		this.taskQueue = taskQueue;
		this.leasesQueue = new LinkedBlockingQueue<>();
		this.launchedTasks = new HashMap<>();
		this.mapTasks = new HashMap<>();

		this.taskCmdGetter = new Func1<String, String>() {
			@Override
			public String call(String t1) {
				return mapTasks.get(t1).getCommand();
			}
		};
		scheduler = new TaskScheduler.Builder().withLeaseOfferExpirySecs(2)
				.withLeaseRejectAction(new Action1<VirtualMachineLease>() {
					@Override
					public void call(VirtualMachineLease lease) {
						logger.info("Declining offer on {}", lease.hostname());
						ref.get().declineOffer(lease.getOffer().getId());
					}
				}).build();
		Protos.FrameworkInfo framework = Protos.FrameworkInfo.newBuilder()
				.setName("TSDV Framework").setUser("").build();
		Scheduler mesosScheduler = new CustomScheduler();
		this.mesosSchedulerDriver = new MesosSchedulerDriver(mesosScheduler,
				framework, mesosMaster);
		ref.set(mesosSchedulerDriver);
	}

	void runAll() {
		System.out.println("Running all");
		List<VirtualMachineLease> newLeases = new ArrayList<>();
		while (true) {
			if (isShutdown.get())
				return;
			newLeases.clear();
			List<TaskRequest> newTaskRequests = new ArrayList<>();
			System.out.println("#Pending tasks: " + pendingTasksMap.size());
			TaskRequest taskRequest = null;
			try {
				taskRequest = pendingTasksMap.size() == 0
						? taskQueue.poll(5, TimeUnit.SECONDS)
						: taskQueue.poll(1, TimeUnit.MILLISECONDS);
			} catch (InterruptedException ie) {
				System.err.println(
						"Error polling task queue: " + ie.getMessage());
			}
			if (taskRequest != null) {
				taskQueue.drainTo(newTaskRequests);
				newTaskRequests.add(0, taskRequest);
				for (TaskRequest request : newTaskRequests)
					pendingTasksMap.put(request.getId(), request);
			}
			leasesQueue.drainTo(newLeases);
			SchedulingResult schedulingResult = scheduler.scheduleOnce(
					new ArrayList<>(pendingTasksMap.values()), newLeases);
			System.out.println("result=" + schedulingResult);
			Map<String, VMAssignmentResult> resultMap = schedulingResult
					.getResultMap();
			if (!resultMap.isEmpty()) {
				for (VMAssignmentResult result : resultMap.values()) {
					List<VirtualMachineLease> leasesUsed = result
							.getLeasesUsed();
					List<Protos.TaskInfo> taskInfos = new ArrayList<>();
					StringBuilder stringBuilder = new StringBuilder(
							"Launching on VM " + leasesUsed.get(0).hostname()
									+ " tasks ");
					final Protos.SlaveID slaveId = leasesUsed.get(0).getOffer()
							.getSlaveId();
					for (TaskAssignmentResult t : result.getTasksAssigned()) {
						stringBuilder.append(t.getTaskId()).append(", ");
						taskInfos.add(getTaskInfo(slaveId, t.getTaskId()));
						// remove task from pending tasks map and put into
						// launched tasks map
						// (in real world, transition the task state)
						pendingTasksMap.remove(t.getTaskId());
						launchedTasks.put(t.getTaskId(),
								leasesUsed.get(0).hostname());
						scheduler.getTaskAssigner().call(t.getRequest(),
								leasesUsed.get(0).hostname());
					}
					List<Protos.OfferID> offerIDs = new ArrayList<>();
					for (VirtualMachineLease l : leasesUsed)
						offerIDs.add(l.getOffer().getId());
					System.out.println(stringBuilder.toString());
					mesosSchedulerDriver.launchTasks(offerIDs, taskInfos);
				}
			}
			// insert a short delay before scheduling any new tasks or tasks
			// from before that haven't been launched yet.
			try {
				Thread.sleep(100);
			} catch (InterruptedException ie) {
			}
		}
	}

	private Protos.TaskInfo getTaskInfo(Protos.SlaveID slaveID,
			final String taskId) {
		Protos.TaskID pTaskId = Protos.TaskID.newBuilder().setValue(taskId)
				.build();
		return Protos.TaskInfo.newBuilder()
				.setName("task " + pTaskId.getValue()).setTaskId(pTaskId)
				.setSlaveId(slaveID)
				.addResources(Protos.Resource.newBuilder().setName("cpus")
						.setType(Protos.Value.Type.SCALAR).setScalar(
								Protos.Value.Scalar.newBuilder().setValue(1)))
				.addResources(Protos.Resource.newBuilder().setName("mem")
						.setType(Protos.Value.Type.SCALAR).setScalar(
								Protos.Value.Scalar.newBuilder().setValue(128)))
				.setCommand(Protos.CommandInfo.newBuilder()
						.setValue(taskCmdGetter.call(taskId)).build())
				.build();
	}
}
