package com.tsdv.mesosframework.job;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.netflix.fenzo.ConstraintEvaluator;
import com.netflix.fenzo.TaskRequest;
import com.netflix.fenzo.VMTaskFitnessCalculator;

public class Job implements TaskRequest {

	public static class Builder {
		private String id;
		private String name;
		private String command;
		private double cpus;
		private double memory;
		private int retries;
		private JobState status;
		private String groupName;
		private Map<String, String> environment = new HashMap<>();

		public void setId(String id) {
			this.id = id;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void setCommand(String command) {
			this.command = command;
		}

		public void setCpus(double cpus) {
			this.cpus = cpus;
		}

		public void setMemory(double memory) {
			this.memory = memory;
		}

		public void setRetries(int retries) {
			this.retries = retries;
		}

		public void setStatus(JobState status) {
			this.status = status;
		}

		public void setEnvironment(Map<String, String> environment) {
			this.environment = environment;
		}

		public Job build() {
			Preconditions.checkNotNull(this.command, "command must be set!");
			Preconditions.checkNotNull(this.memory, "memory must be set!");
			Preconditions.checkNotNull(this.cpus, "cpus must be set!");
			if (this.id == null) {
				this.id = UUID.randomUUID().toString();
			}
			if (this.name == null) {
				this.name = "Job Name";
			}
			if (this.groupName == null) {
				this.groupName = "";
			}
			return new Job(id, name, command, cpus, memory, groupName, retries,
					status, environment);
		}

	}

	private String id;
	private String name;
	private String command;
	private String taskGroupName;
	private double cpus;
	private double memory;
	private double disk;
	private int port;
	private int retries;
	private JobState status;
	private double networkMbps;
	private Map<String, String> environment = new HashMap<>();
	private Map<String, Double> scalarRequest;
	private List<? extends ConstraintEvaluator> hardConstraint;
	private List<? extends VMTaskFitnessCalculator> softConstraint;
	final AtomicReference<TaskRequest.AssignedResources> assgndResRef = new AtomicReference<>();

	private Job(String id, String name, String command, double cpus,
			double memory, String groupName, int retries, JobState status,
			Map<String, String> environment) {
		this.id = id;
		this.name = name;
		this.taskGroupName = groupName;
		this.command = command;
		this.cpus = cpus;
		this.memory = memory;
		this.retries = retries;
		this.status = status;
		this.environment = ImmutableMap.copyOf(environment);
		this.retries = 5;
	}

	public int getRetries() {
		return retries;
	}

	public void setRetries(int retries) {
		this.retries = retries;
	}

	public JobState getStatus() {
		return status;
	}

	public void setStatus(JobState status) {
		this.status = status;
	}

	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public String taskGroupName() {
		return this.taskGroupName;
	}

	@Override
	public double getCPUs() {
		return this.cpus;
	}

	@Override
	public double getMemory() {
		return this.memory;
	}

	@Override
	public double getNetworkMbps() {
		return this.networkMbps;
	}

	@Override
	public double getDisk() {
		return this.disk;
	}

	@Override
	public int getPorts() {
		return this.port;
	}

	@Override
	public Map<String, Double> getScalarRequests() {
		return this.scalarRequest;
	}

	@Override
	public Map<String, NamedResourceSetRequest> getCustomNamedResources() {
		return Collections.emptyMap();
	}

	@Override
	public List<? extends ConstraintEvaluator> getHardConstraints() {
		return this.hardConstraint;
	}

	@Override
	public List<? extends VMTaskFitnessCalculator> getSoftConstraints() {
		return this.softConstraint;
	}

	@Override
	public void setAssignedResources(AssignedResources assignedResources) {
		assgndResRef.set(assignedResources);

	}

	@Override
	public AssignedResources getAssignedResources() {
		return assgndResRef.get();
	}

	public String getCommand() {
		return this.command;
	}

}
