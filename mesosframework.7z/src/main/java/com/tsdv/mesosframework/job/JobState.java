package com.tsdv.mesosframework.job;

public enum JobState {
	PENDING,			/* PEDING status*/
	STAGING, 			/* STAGING status*/
	RUNNING, 			/* RUNNING status*/
	SUCCESSFUL, 		/* SUCCESSFUL status*/
	FAILED				/* FAILED status*/
}
