package com.tsdv.mesosframework.job;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import com.netflix.fenzo.ConstraintEvaluator;
import com.netflix.fenzo.TaskRequest;
import com.netflix.fenzo.VMTaskFitnessCalculator;

public class Task implements TaskRequest {
	private String id;
	private String taskGroupName;
	private double cpus;
	private double memory;
	private double networkMbps;
	private double disk;
	private String command;
	private int port;
	private Map<String, Double> scalarRequest;
	private List<? extends ConstraintEvaluator> hardConstraint;
	private List<? extends VMTaskFitnessCalculator> softConstraint;

	final AtomicReference<TaskRequest.AssignedResources> assgndResRef = new AtomicReference<>();

	public Task(String id, String command, String taskGroupName, double cpus,
			double memory, double networkMbps, double disk, int port,
			Map<String, Double> scalarRequest,
			List<? extends ConstraintEvaluator> hardConstraint,
			List<? extends VMTaskFitnessCalculator> softConstraint) {
		super();
		this.id = id;
		this.taskGroupName = taskGroupName;
		this.cpus = cpus;
		this.memory = memory;
		this.networkMbps = networkMbps;
		this.disk = disk;
		this.port = port;
		this.command = command;
		this.scalarRequest = scalarRequest;
		this.hardConstraint = hardConstraint;
		this.softConstraint = softConstraint;
	}

	public Task(String id, String command, double cpus, double memory) {
		this(id, command, "", cpus, memory, 0, 0, 1, null, null, null);
	}

	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public String taskGroupName() {
		return this.taskGroupName;
	}

	@Override
	public double getCPUs() {
		return this.cpus;
	}

	@Override
	public double getMemory() {
		return this.memory;
	}

	@Override
	public double getNetworkMbps() {
		return this.networkMbps;
	}

	@Override
	public double getDisk() {
		return this.disk;
	}

	@Override
	public int getPorts() {
		return this.port;
	}

	@Override
	public Map<String, Double> getScalarRequests() {
		return this.scalarRequest;
	}

	@Override
	public Map<String, NamedResourceSetRequest> getCustomNamedResources() {
		return Collections.emptyMap();
	}

	@Override
	public List<? extends ConstraintEvaluator> getHardConstraints() {
		return this.hardConstraint;
	}

	@Override
	public List<? extends VMTaskFitnessCalculator> getSoftConstraints() {
		return this.softConstraint;
	}

	@Override
	public void setAssignedResources(AssignedResources assignedResources) {
		assgndResRef.set(assignedResources);

	}

	@Override
	public AssignedResources getAssignedResources() {
		return assgndResRef.get();
	}

	public String getCommand() {
		return this.command;
	}
}
